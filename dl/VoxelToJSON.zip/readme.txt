-bitKoder's Voxel to JSON Converter-

HOW TO USE:
1. Open a MagicaVoxel Voxel Model (a .vox file) by pressing the "Open Voxel Model (.vox)" button and nagivating to the desired file.
2. Configure the scale and offset to suit your needs. Scale controls how large, in pixels (1/16ths of a block) each voxel is. Offset controls how far in each dimension from the lowermost corner the model is (also measured in pixels).
3. Click the "Export Minecraft Model Files" to save your model in a file Minecraft can read, then navigate to the folder where you saved your file.
4. Next to the file you just saved, you will notice a folder called "voxel". This is where all the textures for the voxel colors go. Copy the "voxel" folder into your resource pack's "textures" folder.
5. Finally, place the .json model file you saved in your resource pack's "models\block" or "models\item" folder, if it isn't already. Name it appropriately to overwrite the desired block/item.
6. Launch Minecraft, and select your resource pack from the "Resource Packs" menu. Now you can open up a world, and your voxel models should be visible!

If the old model is still being used instead of your new model, reload the resource pack by pressing F3+T. If that doesn't work, or something went wrong during any of these steps, contact me on twitter @bitKoder.
Enjoy!